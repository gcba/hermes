//
//  RatingsSDK.h
//  RatingsSDK
//
//  Created by Rita Zerrizuela on 7/25/17.
//  Copyright © 2017 GCBA. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RatingsSDK.
FOUNDATION_EXPORT double RatingsSDKVersionNumber;

//! Project version string for RatingsSDK.
FOUNDATION_EXPORT const unsigned char RatingsSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RatingsSDK/PublicHeader.h>


